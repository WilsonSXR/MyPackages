# MyPackages
This library was created as an example to how to publish your own python package.